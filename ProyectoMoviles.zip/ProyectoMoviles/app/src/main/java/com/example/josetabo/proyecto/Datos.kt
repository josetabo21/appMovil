package com.example.josetabo.proyecto

class Datos {
    companion object {
        val Lectura: ArrayList<Lectura> = ArrayList()
    }
}